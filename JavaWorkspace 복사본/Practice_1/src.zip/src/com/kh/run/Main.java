package com.kh.run;

import com.kh.prac.Practice;

public class Main {

	public static void main(String[] args) {
		new Practice().prac();

	}

}
