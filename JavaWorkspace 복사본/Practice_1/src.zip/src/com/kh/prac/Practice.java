package com.kh.prac;

public class Practice {
	
	public void prac() {
		//놀이공원 소개
		
		byte minAge = 3;
		short maxAge = 100;
		char grade = 'A';
		int minEnter = 10000000;
		long maxEnter = 999999999;
		boolean runHoliday = true;
		float discount = 30;
		double crewDiscount = 50;
		
		System.out.println("입장 가능한 최소 나이:  " + minAge + "세");
		System.out.println("입장 가능한 최대 나이:  " + maxAge + "세");
		System.out.println("시설 등급:  " + grade);
		System.out.println("최소 수용 인원:  " + minEnter + "명");
		System.out.println("최대 수용 인원:  " + maxEnter + "명");
		System.out.println("공휴일 영업 여부:  " + runHoliday);
		System.out.println("kh카드 할인율:  " + discount + "%");
		System.out.println("직원 할인율:  " + crewDiscount + "%");
		
		
	}

}
